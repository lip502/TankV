package model;

import java.awt.Graphics;

import util.Data;
import util.DataMap;

public class Home extends Atlas {
	
	public Home(int xp,int yp) {
	
		this.setXp(xp);
		
		this.setYp(yp);
		
		//this.setType(5);
	}

	@Override
	public void drawMe(Graphics g) {
	
		//画老巢
		g.drawImage(DataMap.IMG_HOME, this.getXp(), this.getYp(), this.getXp() + Data.PLAYER_SIZE, this.getYp() + Data.PLAYER_SIZE, 
						0, 0, Data.PLAYER_SIZE, Data.PLAYER_SIZE, null);

	}

}
