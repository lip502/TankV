package model;

import java.awt.Graphics;

import util.Data;

public class PlayerBullet {

	// 成员属性 xy坐标
	private int xp;

	private int yp;
	// 子弹方向
	private int bulletDirection;

	public PlayerBullet() {
		// TODO Auto-generated constructor stub
	}

	public PlayerBullet(int xp, int yp, int bulletDirection) {
		super();
		this.xp = xp;
		this.yp = yp;
		this.bulletDirection = bulletDirection;
	}

	// 画自己的方法
	public void drawMe(Graphics g) {

		g.drawImage(Data.IMGBULLET, xp, yp, xp+Data.BULLET_SIZE, yp+Data.BULLET_SIZE, 0, 0, Data.BULLET_SIZE,
				Data.BULLET_SIZE, null);
	}

	// 子弹移动的方法
	public void bulletMove() {
		
		if (bulletDirection == 1) {
			// 向上
			yp -= 5;
		} else if (bulletDirection == 2) {
			// 向下
			yp += 5;
		} else if (bulletDirection == 3) {
			// 向左
			xp -= 5;
		} else if (bulletDirection == 4) {
			// 向右
			xp += 5;
		}
	}

	public int getXp() {
		return xp;
	}

	public void setXp(int xp) {
		this.xp = xp;
	}

	public int getYp() {
		return yp;
	}

	public void setYp(int yp) {
		this.yp = yp;
	}

	public int getBulletDirection() {
		return bulletDirection;
	}

	public void setBulletDirection(int bulletDirection) {
		this.bulletDirection = bulletDirection;
	}

}
