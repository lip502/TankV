package model;

import java.awt.Color;
import java.awt.Graphics;

import util.Data;

public class Player {

	// x坐标
	private int xp;
	// y坐标
	private int yp;
	// 血量
	private int hp;
	// 生命
	private int life;
	// 攻击力
	private int attack;

	// 空参构造
	public Player() {

	}

	// 有参构造
	public Player(int xp, int yp) {
		super();
		this.xp = xp;

		this.yp = yp;

		this.hp = 3;

		this.life = 3;

		this.attack = 1;
	}

	// 画自己
	public void drawMe(Graphics g) {

		// 方向向上
		if (Data.playerDirection == 1) {
			// 画玩家
			g.drawImage(Data.IMGPLAYER, xp, yp, xp + Data.PLAYER_SIZE, yp + Data.PLAYER_SIZE, Data.PLAYER_SIZE, 0,
					Data.PLAYER_SIZE * 2, Data.PLAYER_SIZE, null);
			//改变画笔颜色
			g.setColor(Color.BLACK);
			// 画空心矩形
			g.drawRect(xp, yp + Data.HP_UP, Data.PLAYER_SIZE, Data.HP_H);

			if (hp == 3) {
				// 改变画笔颜色
				g.setColor(Color.GREEN);
				// 画实心矩形
				g.fillRect(xp, yp + Data.HP_UP, Data.PLAYER_SIZE, Data.HP_H);

			} else if (hp == 2) {
				// 改变颜色
				g.setColor(Color.YELLOW);
				// 画黄色矩形
				g.fillRect(xp, yp + Data.HP_UP, Data.PLAYER_SIZE / 3 * 2, Data.HP_H);

			} else if (hp == 1) {
				// 改变颜色
				g.setColor(Color.RED);
				// 画红色矩形
				g.fillRect(xp, yp + Data.HP_UP, Data.PLAYER_SIZE / 3, Data.HP_H);

			}
			// 方向向下
		} else if (Data.playerDirection == 2) {

			// 画玩家
			g.drawImage(Data.IMGPLAYER, xp, yp, xp + Data.PLAYER_SIZE, yp + Data.PLAYER_SIZE, Data.PLAYER_SIZE * 2, 0,
					Data.PLAYER_SIZE * 3, Data.PLAYER_SIZE, null);

			//改变画笔颜色
			g.setColor(Color.BLACK);
			// 画空心矩形
			g.drawRect(xp, yp - Data.HP_DOWN, Data.PLAYER_SIZE, Data.HP_H);

			if (hp == 3) {

				// 改变画笔颜色
				g.setColor(Color.GREEN);
				// 画实心矩形
				g.fillRect(xp, yp - Data.HP_DOWN, Data.PLAYER_SIZE, Data.HP_H);

			} else if (hp == 2) {
				// 改变颜色
				g.setColor(Color.YELLOW);
				// 画黄色矩形
				g.fillRect(xp, yp - Data.HP_DOWN, Data.PLAYER_SIZE / 3 * 2, Data.HP_H);

			} else if (hp == 1) {

				// 改变颜色
				g.setColor(Color.RED);
				// 画红色矩形
				g.fillRect(xp, yp-Data.HP_DOWN, Data.PLAYER_SIZE / 3, Data.HP_H);

			}
			// 方向向左
		} else if (Data.playerDirection == 3) {

			// 画玩家
			g.drawImage(Data.IMGPLAYER, xp, yp, xp + Data.PLAYER_SIZE, yp + Data.PLAYER_SIZE, 0, 0, Data.PLAYER_SIZE,
					Data.PLAYER_SIZE, null);

			//改变画笔颜色
			g.setColor(Color.BLACK);
			// 画空心矩形
			g.drawRect(xp + Data.HP_UP, yp, Data.HP_H, Data.PLAYER_SIZE);

			if (hp == 3) {

				// 改变画笔颜色
				g.setColor(Color.GREEN);
				// 画实心矩形
				g.fillRect(xp + Data.HP_UP, yp, Data.HP_H, Data.PLAYER_SIZE);

			} else if (hp == 2) {
				// 改变颜色
				g.setColor(Color.YELLOW);
				// 画黄色矩形
				g.fillRect(xp + Data.HP_UP, yp, Data.HP_H, Data.PLAYER_SIZE / 3 * 2);

			} else if (hp == 1) {

				// 改变颜色
				g.setColor(Color.RED);
				// 画红色矩形
				g.fillRect(xp + Data.HP_UP, yp, Data.HP_H, Data.PLAYER_SIZE / 3);

			}

			// 方向向右
		} else if (Data.playerDirection == 4) {

			// 画玩家
			g.drawImage(Data.IMGPLAYER, xp, yp, xp + Data.PLAYER_SIZE, yp + Data.PLAYER_SIZE, Data.PLAYER_SIZE * 3, 0,
					Data.PLAYER_SIZE * 4, Data.PLAYER_SIZE, null);

			//改变画笔颜色
			g.setColor(Color.BLACK);
			// 画空心矩形
			g.drawRect(xp - Data.HP_DOWN, yp, Data.HP_H, Data.PLAYER_SIZE);

			if (hp == 3) {

				// 改变画笔颜色
				g.setColor(Color.GREEN);
				// 画实心矩形
				g.fillRect(xp - Data.HP_DOWN, yp, Data.HP_H, Data.PLAYER_SIZE);

			} else if (hp == 2) {
				// 改变颜色
				g.setColor(Color.YELLOW);
				// 画黄色矩形
				g.fillRect(xp - Data.HP_DOWN, yp, Data.HP_H, Data.PLAYER_SIZE / 3 * 2);

			} else if (hp == 1) {

				// 改变颜色
				g.setColor(Color.RED);
				// 画红色矩形
				g.fillRect(xp - Data.HP_DOWN, yp, Data.HP_H, Data.PLAYER_SIZE / 3);

			}
		}

	}

	// 玩家移动的方法
	public void playerMove() {
		
		if (Data.playerMove == 1) {
			// 边界判断
			if (yp > 0) {
				// 向上移动
				yp -= 5;
			}

		} else if (Data.playerMove == 2) {
			// 边界判断
			if (yp < Data.GAMEBG_SIZE - Data.PLAYER_SIZE) {
				// 向下移动
				yp += 5;
			}

		} else if (Data.playerMove == 3) {
			// 边界判断
			if (xp > 0) {
				// 向左移动
				xp -= 5;
			}

		} else if (Data.playerMove == 4) {
			// 边界判断
			if (xp < Data.GAMEBG_SIZE - Data.PLAYER_SIZE) {
				// 向右移动
				xp += 5;
			}
		}
	}

	public int getXp() {
		return xp;
	}

	public void setXp(int xp) {
		this.xp = xp;
	}

	public int getYp() {
		return yp;
	}

	public void setYp(int yp) {
		this.yp = yp;
	}

	public int getHp() {
		return hp;
	}

	public void setHp(int hp) {
		this.hp = hp;
	}

	public int getLife() {
		return life;
	}

	public void setLife(int life) {
		this.life = life;
	}

	public int getAttack() {
		return attack;
	}

	public void setAttack(int attack) {
		this.attack = attack;
	}

}
