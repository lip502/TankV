package model;

import java.awt.Graphics;

import util.Data;
import util.DataMap;

public class Steels extends Atlas {
	
	public Steels(int xp,int yp) {
		
		this.setXp(xp);
		
		this.setYp(yp);
		
		
		
		//this.setType(4);
		
	}
	

	@Override
	public void drawMe(Graphics g) {
		
		//画铁
		g.drawImage(DataMap.IMG_STEELS, this.getXp(), this.getYp(), this.getXp() + Data.PLAYER_SIZE, this.getYp() + Data.PLAYER_SIZE, 
						0, 0, Data.PLAYER_SIZE, Data.PLAYER_SIZE, null);

	}

}
