package model;

import java.awt.Graphics;

import util.Data;

public abstract class Enemy {

	// x坐标
	private int xp;
	// y坐标
	private int yp;
	// 血量
	private int hp;
	// 攻击力
	private int attack;
	// 类型
	private char type;
	// 方向
	private int enemyDirection;
	// 分数
	private int grade;

	// 画自己的方法
	public abstract void drawMe(Graphics g);

	// 敌人移动的方法
	public abstract void enemyMove();

	public int getXp() {
		return xp;
	}

	public void setXp(int xp) {
		this.xp = xp;
	}

	public int getYp() {
		return yp;
	}

	public void setYp(int yp) {
		this.yp = yp;
	}

	public int getHp() {
		return hp;
	}

	public void setHp(int hp) {
		this.hp = hp;
	}

	public int getAttack() {
		return attack;
	}

	public void setAttack(int attack) {
		this.attack = attack;
	}

	public char getType() {
		return type;
	}

	public void setType(char type) {
		this.type = type;
	}

	public int getEnemyDirection() {
		return enemyDirection;
	}

	public void setEnemyDirection(int enemyDirection) {
		this.enemyDirection = enemyDirection;
	}

	public int getGrade() {
		return grade;
	}

	public void setGrade(int grade) {
		this.grade = grade;
	}

}
