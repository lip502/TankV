  package model;

import java.awt.Color;
import java.awt.Graphics;

import util.Data;

public class GreenEnemy extends Enemy {

	public GreenEnemy(int xp, int yp) {

		// x坐标
		this.setXp(xp);
		// y坐标
		this.setYp(yp);
		// 类型
		this.setType('C');
		// 血量
		this.setHp(1);
		// 攻击力
		this.setAttack(1);
		// 分值
		this.setGrade(100);
		//方向向下
		this.setEnemyDirection(2);
	}

	//重写画自己的方法
	@Override
	public void drawMe(Graphics g) {
		
		//向上
		if(this.getEnemyDirection() == 1) {
			
			g.drawImage(Data.IMG_GREENENEMY, this.getXp(), this.getYp(), this.getXp() + Data.PLAYER_SIZE,
					this.getYp() + Data.PLAYER_SIZE, Data.PLAYER_SIZE, 0, Data.PLAYER_SIZE * 2, Data.PLAYER_SIZE, null);
			
			// 画空心矩形
			//g.drawRect(this.getXp(), this.getYp() + Data.HP_UP, Data.PLAYER_SIZE, Data.HP_H);
			
			// 改变画笔颜色
			g.setColor(Color.GREEN);
			// 画实心矩形
			g.fillRect(this.getXp(), this.getYp() + Data.HP_UP, Data.PLAYER_SIZE, Data.HP_H);
			
			//向下
		}else if(this.getEnemyDirection() == 2) {
			
			// 画敌人
			g.drawImage(Data.IMG_GREENENEMY, this.getXp(), this.getYp(), this.getXp() + Data.PLAYER_SIZE, this.getYp() + Data.PLAYER_SIZE,
					Data.PLAYER_SIZE * 2, 0,
					Data.PLAYER_SIZE * 3, Data.PLAYER_SIZE, null);
									
			// 画空心矩形
			//g.drawRect(this.getXp(), this.getYp() - Data.HP_DOWN, Data.PLAYER_SIZE, Data.HP_H);
			
			// 改变画笔颜色
			g.setColor(Color.GREEN);
			// 画实心矩形
			g.fillRect(this.getXp(), this.getYp() - Data.HP_DOWN, Data.PLAYER_SIZE, Data.HP_H);
			
			//向左
		}else if(this.getEnemyDirection() == 3) {
			
			// 画敌人
			g.drawImage(Data.IMG_GREENENEMY, this.getXp(), this.getYp(), this.getXp() + Data.PLAYER_SIZE, 
					this.getYp() + Data.PLAYER_SIZE, 0, 0, Data.PLAYER_SIZE,
						Data.PLAYER_SIZE, null);

			// 画空心矩形
			//g.drawRect(this.getXp() + Data.HP_UP, this.getYp(), Data.HP_H, Data.PLAYER_SIZE);
			
			// 改变画笔颜色
			g.setColor(Color.GREEN);
			// 画实心矩形
			g.fillRect(this.getXp() + Data.HP_UP, this.getYp(), Data.HP_H, Data.PLAYER_SIZE);
			
			//向右
		}else if(this.getEnemyDirection() == 4) {
			
			// 画敌人
			g.drawImage(Data.IMG_GREENENEMY, this.getXp(), this.getYp(), this.getXp() + Data.PLAYER_SIZE,
					this.getYp() + Data.PLAYER_SIZE, Data.PLAYER_SIZE * 3, 0,
						Data.PLAYER_SIZE * 4, Data.PLAYER_SIZE, null);

			// 画空心矩形
			//g.drawRect(this.getXp() - Data.HP_DOWN, this.getYp(), Data.HP_H, Data.PLAYER_SIZE);
			
			// 改变画笔颜色
			g.setColor(Color.GREEN);
			// 画实心矩形
			g.fillRect(this.getXp() - Data.HP_DOWN, this.getYp(), Data.HP_H, Data.PLAYER_SIZE);
			
		}
		

	}

	public void enemyMove() {
		
		if (this.getEnemyDirection() == 1) {
			
			if (this.getYp()> 0) {
				// 向上移动
				this.setYp(this.getYp()-Data.enemyStep ) ;
			}

		} else if (this.getEnemyDirection() == 2) {

			if (this.getYp() < Data.GAMEBG_SIZE - Data.PLAYER_SIZE) {
				// 向下移动
				this.setYp(this.getYp()+Data.enemyStep );
			}

		} else if (this.getEnemyDirection() == 3) {
			
			if (this.getXp() > 0) {
				// 向左移动
				this.setXp(this.getXp()-Data.enemyStep );
			}

		} else if (this.getEnemyDirection() == 4) {

			if (this.getXp() < Data.GAMEBG_SIZE - Data.PLAYER_SIZE) {
				// 向右移动
				this.setXp(this.getXp()+Data.enemyStep );
			}
		}
		
	}
}
