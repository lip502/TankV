package model;

import java.awt.Graphics;

import util.Data;
import util.DataMap;

public class Grass extends Atlas {
	
	public Grass(int xp,int yp) {
		
		this.setXp(xp);
		
		this.setYp(yp);
		
		//this.setType(1);
		
		
		
	}

	@Override
	public void drawMe(Graphics g) {
		// TODO Auto-generated method stub

		g.drawImage(DataMap.IMG_GRASS, this.getXp(), this.getYp(), this.getXp() + Data.PLAYER_SIZE, this.getYp() + Data.PLAYER_SIZE, 
				0, 0, Data.PLAYER_SIZE, Data.PLAYER_SIZE, null);
	}

}
