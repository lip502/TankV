package model;

import java.awt.Graphics;

import util.Data;
import util.DataMap;

public class Water extends Atlas {
	
	public Water(int xp,int yp) {

		this.setXp(xp);
		
		this.setYp(yp);
		
	

	}
	

	@Override
	public void drawMe(Graphics g) {
		//画水
		g.drawImage(DataMap.IMG_WATER, this.getXp(), this.getYp(), this.getXp() + Data.PLAYER_SIZE, this.getYp() + Data.PLAYER_SIZE, 
				0, 0, Data.PLAYER_SIZE, Data.PLAYER_SIZE, null);

	}

}
