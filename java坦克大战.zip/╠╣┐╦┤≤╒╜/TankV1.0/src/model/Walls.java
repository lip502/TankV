package model;

import java.awt.Graphics;

import util.Data;
import util.DataMap;

public class Walls extends Atlas {
	
	public Walls(int xp,int yp) {
		
		this.setXp(xp);
		
		this.setYp(yp);
		
		this.setHp(2);
		
		
	}
	

	@Override
	public void drawMe(Graphics g) {
		//画墙
		g.drawImage(DataMap.IMG_WALLS, this.getXp(), this.getYp(), this.getXp() + Data.PLAYER_SIZE, this.getYp() + Data.PLAYER_SIZE, 
				0, 0, Data.PLAYER_SIZE, Data.PLAYER_SIZE, null);
		
	}

}
