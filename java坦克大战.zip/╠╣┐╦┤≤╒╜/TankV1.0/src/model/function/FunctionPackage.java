package model.function;

import java.awt.Graphics;

public abstract class FunctionPackage {
	//x坐标
	private int xp;
	//y坐标
	private int yp;
	
	
	//画自己
	public abstract void drawMe(Graphics g);

	
	public int getXp() {
		return xp;
	}

	public void setXp(int xp) {
		this.xp = xp;
	}

	public int getYp() {
		return yp;
	}

	public void setYp(int yp) {
		this.yp = yp;
	}
	
	
}
