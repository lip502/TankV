package model.function;

import java.awt.Graphics;

import util.Data;

public class HpFunctionPackage extends FunctionPackage {

	public HpFunctionPackage(int xp, int yp) {
		this.setXp(xp);
		this.setYp(yp);
	}

	@Override
	public void drawMe(Graphics g) {
		// TODO Auto-generated method stub
		g.drawImage(Data.HP_IMG, this.getXp(), this.getYp(), this.getXp() + Data.PACKGE_SIZE,
				this.getYp() + Data.PACKGE_SIZE, 0, 0, Data.PACKGE_SIZE, Data.PACKGE_SIZE, null);
	}
	
}
