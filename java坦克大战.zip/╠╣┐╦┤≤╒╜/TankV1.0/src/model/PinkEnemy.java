package model;

import java.awt.Color;
import java.awt.Graphics;

import util.Data;

public class PinkEnemy extends Enemy {

	public PinkEnemy(int xp, int yp) {

		// x坐标
		this.setXp(xp);
		// y坐标
		this.setYp(yp);
		// 类型
		this.setType('B');
		// 血量
		this.setHp(2);
		// 攻击力
		this.setAttack(2);
		// 分值
		this.setGrade(200);
		// 方向向下
		this.setEnemyDirection(2);

	}

	// 重写画自己的方法
	@Override
	public void drawMe(Graphics g) {

		// 向上的时候
		if (this.getEnemyDirection() == 1) {

			g.drawImage(Data.IMG_PINKENEMY, this.getXp(), this.getYp(), this.getXp() + Data.PLAYER_SIZE,
					this.getYp() + Data.PLAYER_SIZE, Data.PLAYER_SIZE, 0, Data.PLAYER_SIZE * 2, Data.PLAYER_SIZE, null);
			//改变画笔颜色
			g.setColor(Color.black);
			// 画空心矩形
			g.drawRect(this.getXp(), this.getYp() + Data.HP_UP, Data.PLAYER_SIZE, Data.HP_H);

			if (this.getHp() == 2) {

				// 改变画笔颜色
				g.setColor(Color.GREEN);
				// 画实心矩形
				g.fillRect(this.getXp(), this.getYp() + Data.HP_UP, Data.PLAYER_SIZE, Data.HP_H);

			} else if (this.getHp() == 1) {

				// 改变颜色
				g.setColor(Color.RED);
				// 画红色矩形
				g.fillRect(this.getXp(), this.getYp() + Data.HP_UP, Data.PLAYER_SIZE / 2, Data.HP_H);
			}
			// 向下的时候
		} else if (this.getEnemyDirection() == 2) {

			// 画敌人
			g.drawImage(Data.IMG_PINKENEMY, this.getXp(), this.getYp(), this.getXp() + Data.PLAYER_SIZE,
					this.getYp() + Data.PLAYER_SIZE, Data.PLAYER_SIZE * 2, 0, Data.PLAYER_SIZE * 3, Data.PLAYER_SIZE,
					null);

			//改变画笔颜色
			g.setColor(Color.black);
			// 画空心矩形
			g.drawRect(this.getXp(), this.getYp() - Data.HP_DOWN, Data.PLAYER_SIZE, Data.HP_H);

			if (this.getHp() == 2) {

				// 改变画笔颜色
				g.setColor(Color.GREEN);
				// 画实心矩形
				g.fillRect(this.getXp(), this.getYp() - Data.HP_DOWN, Data.PLAYER_SIZE, Data.HP_H);

			} else if (this.getHp() == 1) {

				// 改变颜色
				g.setColor(Color.RED);
				// 画红色矩形
				g.fillRect(this.getXp(), this.getYp()-Data.HP_DOWN, Data.PLAYER_SIZE / 2, Data.HP_H);

			}
			// 向左的时候
		} else if (this.getEnemyDirection() == 3) {

			// 画敌人
			g.drawImage(Data.IMG_PINKENEMY, this.getXp(), this.getYp(), this.getXp() + Data.PLAYER_SIZE,
					this.getYp() + Data.PLAYER_SIZE, 0, 0, Data.PLAYER_SIZE, Data.PLAYER_SIZE, null);

			//改变画笔颜色
			g.setColor(Color.black);
			// 画空心矩形
			g.drawRect(this.getXp() + Data.HP_UP, this.getYp(), Data.HP_H, Data.PLAYER_SIZE);

			if (this.getHp() == 2) {

				// 改变画笔颜色
				g.setColor(Color.GREEN);
				// 画实心矩形
				g.fillRect(this.getXp() + Data.HP_UP, this.getYp(), Data.HP_H, Data.PLAYER_SIZE);

			} else if (this.getHp() == 1) {

				// 改变颜色
				g.setColor(Color.RED);
				// 画红色矩形
				g.fillRect(this.getXp() + Data.HP_UP, this.getYp(), Data.HP_H, Data.PLAYER_SIZE / 2);

			}
			// 向右的时候
		} else if (this.getEnemyDirection() == 4) {

			// 画敌人
			g.drawImage(Data.IMG_PINKENEMY, this.getXp(), this.getYp(), this.getXp() + Data.PLAYER_SIZE,
					this.getYp() + Data.PLAYER_SIZE, Data.PLAYER_SIZE * 3, 0, Data.PLAYER_SIZE * 4, Data.PLAYER_SIZE,
					null);

			//改变画笔颜色
			g.setColor(Color.black);
			// 画空心矩形
			g.drawRect(this.getXp() - Data.HP_DOWN, this.getYp(), Data.HP_H, Data.PLAYER_SIZE);

			if (this.getHp() == 2) {

				// 改变画笔颜色
				g.setColor(Color.GREEN);
				// 画实心矩形
				g.fillRect(this.getXp() - Data.HP_DOWN, this.getYp(), Data.HP_H, Data.PLAYER_SIZE);

			} else if (this.getHp() == 1) {

				// 改变颜色
				g.setColor(Color.RED);
				// 画红色矩形
				g.fillRect(this.getXp() - Data.HP_DOWN, this.getYp(), Data.HP_H, Data.PLAYER_SIZE / 2);
			}

		}
	}

	public void enemyMove() {

		if (this.getEnemyDirection() == 1) {

			if (this.getYp() > 0) {
				// 向上移动
				this.setYp(this.getYp() - Data.enemyStep);
			}

		} else if (this.getEnemyDirection() == 2) {

			if (this.getYp() < Data.GAMEBG_SIZE - Data.PLAYER_SIZE) {
				// 向下移动
				this.setYp(this.getYp() + Data.enemyStep);
			}

		} else if (this.getEnemyDirection() == 3) {

			if (this.getXp() > 0) {
				// 向左移动
				this.setXp(this.getXp() - Data.enemyStep);
			}

		} else if (this.getEnemyDirection() == 4) {

			if (this.getXp() < Data.GAMEBG_SIZE - Data.PLAYER_SIZE) {
				// 向右移动
				this.setXp(this.getXp() + Data.enemyStep);
			}
		}

	}
}
