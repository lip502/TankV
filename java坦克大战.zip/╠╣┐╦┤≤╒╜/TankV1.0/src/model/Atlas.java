package model;

import java.awt.Graphics;

public abstract class Atlas {
	// x坐标
	private int xp;
	// y坐标
	private int yp;
	// 血量
	private int hp;

	// 画自己的方法
	public abstract void drawMe(Graphics g);

	public int getXp() {
		return xp;
	}

	public void setXp(int xp) {
		this.xp = xp;
	}

	public int getYp() {
		return yp;
	}

	public void setYp(int yp) {
		this.yp = yp;
	}

	public int getHp() {
		return hp;
	}

	public void setHp(int hp) {
		this.hp = hp;
	}

}
