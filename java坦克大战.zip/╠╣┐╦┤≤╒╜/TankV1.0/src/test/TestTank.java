package test;
import ui.StartGameFrame;
import util.Data;
import util.DataMap;

public class TestTank {

	public static void main(String[] args) {

		// 初始化后台地形集合
		DataMap.FirstMap();

		// 初始化后台敌人集合
		Data.initEnemy();
		// 创建开始游戏的窗口对象
		StartGameFrame f = new StartGameFrame();

		// 设置可见
		f.setVisible(true);

	}

}
