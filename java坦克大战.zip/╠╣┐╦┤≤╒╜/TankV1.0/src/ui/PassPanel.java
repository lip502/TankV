package ui;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;

import util.Data;

public class PassPanel extends JPanel {

	// 退出游戏按钮
	private JButton exitGameBtn = new JButton(new ImageIcon("img/exitgame.png"));
	// 进入下一关游戏按钮
	private JButton nextLevel = new JButton(new ImageIcon("img/nextlevel.png"));
	//重新开始
	private JButton resGame = new JButton(new ImageIcon("img/rest.png"));

	public PassPanel() {

		// 绝对布局
		this.setLayout(null);

		// 设置透明
		exitGameBtn.setContentAreaFilled(false);
		// 设置按钮的位置和添加到面板
		exitGameBtn.setBounds(40, 350, 100, 30);
		this.add(exitGameBtn);

		// 设置透明
		nextLevel.setContentAreaFilled(false);
		nextLevel.setBounds(280, 350, 100, 30);
		this.add(nextLevel);
		
		resGame.setContentAreaFilled(false);
		resGame.setBounds(160, 350, 100, 30);
		this.add(resGame);
		
		// 创建动作监听
		nextLevel.setActionCommand("nextLevel");

		exitGameBtn.setActionCommand("exitGame");
		
		resGame.setActionCommand("rest");
		

	}

	public void paintComponent(Graphics g) {

		// 必须调用此方法
		super.paintComponent(g);

		g.drawImage(Data.IMG_PASS, 0, 0, 430, 400, 0, 0, 430, 400, null);
		
		//改变字体形态
		g.setFont(new Font("楷体", Font.PLAIN, 32));
		//改变颜色
		g.setColor(Color.yellow);
		//画当前关卡
		g.drawString(Data.nowLevel+"", 250, 33);
		//改变颜色
		g.setColor(Color.WHITE);
		//画击杀黄色敌人数量
		g.drawString(Data.hitYellowEnemyCount+"", 125, 82);
		//画黄色敌人得分
		g.drawString(Data.hitYellowEnemyCount*300+"", 330, 82);
		//画击杀粉色敌人数量
		g.drawString(Data.hitPinkEnemyCount+"", 125, 169);
		//画粉色敌人得分
		g.drawString(Data.hitPinkEnemyCount*200+"", 330, 169);
		//画击杀绿色敌人数量
		g.drawString(Data.hitGreenEnemyCount+"", 125, 254);
		//画绿色敌人得分
		g.drawString(Data.hitGreenEnemyCount*100+"", 330, 254);
		//改变画笔颜色
		g.setColor(Color.RED);
		//画当前击杀敌人总数
		g.drawString(Data.nowHit+"", 155, 335);
		//画总共得分
		g.drawString(Data.nowScore+"", 320, 335);

		
		// 刷新画板
		this.repaint();

		
		
	}

	public JButton getExitGameBtn() {
		return exitGameBtn;
	}

	public void setExitGameBtn(JButton exitGameBtn) {
		this.exitGameBtn = exitGameBtn;
	}

	public JButton getNextLevel() {
		return nextLevel;
	}

	public void setNextLevel(JButton nextLevel) {
		this.nextLevel = nextLevel;
	}

	public JButton getResGame() {
		return resGame;
	}

	public void setResGame(JButton resGame) {
		this.resGame = resGame;
	}

}
