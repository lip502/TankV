package ui;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class DiyPanel extends JPanel {

	// 单选框
	private JRadioButton normalGame = new JRadioButton("正常游戏", true);
	private JRadioButton selfDefineGame = new JRadioButton("自选游戏");
	// 下拉框
	private JComboBox<String> levelBox;
	private JComboBox<String> enemySpeedBox;
	private JComboBox<String> enemyBulletSpeedBox;
	private JComboBox<String> enemyBulletTimeBox;
	private JComboBox<String> playerBulletSpeedBox;
	// 文本域
	private JTextField enemyCountText = new JTextField();
	// 标签
	private JLabel levelLabel = new JLabel("请选择关数：");
	private JLabel enemySpeedLabel = new JLabel("敌人移动速度：");
	private JLabel enemyBulletSpeedLabel = new JLabel("敌人子弹速度：");
	private JLabel enemyBulletTimeLabel = new JLabel("敌人射击间隔：");
	private JLabel playerBulletSpeedLabel = new JLabel("玩家子弹速度：");
	private JLabel enemyCountLabel = new JLabel("敌人数量(10-50)：");

	// 按钮
	private JButton sureBtn = new JButton("确定");
	private JButton cancelBtn = new JButton("取消");

	// 单选组
	private ButtonGroup group = new ButtonGroup();

	public DiyPanel() {

		// 绝对布局
		this.setLayout(null);

		// 正常游戏
		normalGame.setBounds(50, 20, 90, 30);
		this.add(normalGame);

		// 自选游戏
		selfDefineGame.setBounds(150, 20, 190, 30);
		this.add(selfDefineGame);

		// 关卡
		levelLabel.setBounds(70, 50, 100, 30);
		this.add(levelLabel);

		String[] levelArr = { "1", "2", "3" };
		levelBox = new JComboBox<String>(levelArr);
		levelBox.setBounds(150, 55, 70, 20);
		// 设置默认值
		levelBox.setSelectedIndex(0);
		this.add(levelBox);

		// 敌人移动速度
		enemySpeedLabel.setBounds(60, 80, 100, 30);
		this.add(enemySpeedLabel);

		String[] enemySpeedArr = { "10", "20", "30", "40" };
		enemySpeedBox = new JComboBox<String>(enemySpeedArr);
		// 设置默认值
		enemySpeedBox.setSelectedIndex(2);
		enemySpeedBox.setBounds(150, 85, 70, 20);
		this.add(enemySpeedBox);

		// 敌人子弹速度
		enemyBulletSpeedLabel.setBounds(60, 110, 100, 30);
		this.add(enemyBulletSpeedLabel);

		String[] enemyBulletSpeedArr = { "5", "10", "20", "30", "40" };
		enemyBulletSpeedBox = new JComboBox<String>(enemyBulletSpeedArr);
		// 设置默认值
		enemyBulletSpeedBox.setSelectedIndex(2);
		enemyBulletSpeedBox.setBounds(150, 115, 70, 20);
		this.add(enemyBulletSpeedBox);

		// 敌人射击间隔
		enemyBulletTimeLabel.setBounds(60, 140, 100, 30);
		this.add(enemyBulletTimeLabel);

		String[] enemyBulletTimeArr = { "100", "500", "1000", "1500", "2000" };
		enemyBulletTimeBox = new JComboBox<String>(enemyBulletTimeArr);
		// 设置默认值
		enemyBulletTimeBox.setSelectedIndex(2);
		enemyBulletTimeBox.setBounds(150, 145, 70, 20);
		this.add(enemyBulletTimeBox);

		// 玩家子弹速度
		playerBulletSpeedLabel.setBounds(60, 170, 100, 30);
		this.add(playerBulletSpeedLabel);

		String[] playerBulletTimeArr = { "5", "10", "20", "30", "40" };
		playerBulletSpeedBox = new JComboBox<String>(playerBulletTimeArr);
		// 设置默认值
		playerBulletSpeedBox.setSelectedIndex(2);
		playerBulletSpeedBox.setBounds(150, 175, 70, 20);
		this.add(playerBulletSpeedBox);

		// 敌人数量
		enemyCountLabel.setBounds(47, 200, 120, 30);
		this.add(enemyCountLabel);
		enemyCountText.setBounds(150, 205, 90, 20);
		this.add(enemyCountText);

		// 确定按钮
		sureBtn.setBounds(70, 240, 60, 30);
		this.add(sureBtn);

		// 取消
		cancelBtn.setBounds(155, 240, 60, 30);
		this.add(cancelBtn);

		// 将单选框加入单选组中 使之只能选一个
		group.add(normalGame);
		group.add(selfDefineGame);

		// 正常游戏时不能选择
		if (normalGame.isSelected()) {
			levelBox.setEnabled(false);
			enemySpeedBox.setEnabled(false);
			enemyBulletSpeedBox.setEnabled(false);
			enemyBulletTimeBox.setEnabled(false);
			playerBulletSpeedBox.setEnabled(false);
			enemyCountText.setEnabled(false);
		}

		// 设置动作命令
		sureBtn.setActionCommand("selfDefineSure");
		cancelBtn.setActionCommand("selfDefineCancel");
		normalGame.setActionCommand("normalGame");
		selfDefineGame.setActionCommand("selfDefineGame");

	}

	public JRadioButton getNormalGame() {
		return normalGame;
	}

	public void setNormalGame(JRadioButton normalGame) {
		this.normalGame = normalGame;
	}

	public JRadioButton getSelfDefineGame() {
		return selfDefineGame;
	}

	public void setSelfDefineGame(JRadioButton selfDefineGame) {
		this.selfDefineGame = selfDefineGame;
	}

	public JComboBox<String> getLevelBox() {
		return levelBox;
	}

	public void setLevelBox(JComboBox<String> levelBox) {
		this.levelBox = levelBox;
	}

	public JComboBox<String> getEnemySpeedBox() {
		return enemySpeedBox;
	}

	public void setEnemySpeedBox(JComboBox<String> enemySpeedBox) {
		this.enemySpeedBox = enemySpeedBox;
	}

	public JComboBox<String> getEnemyBulletSpeedBox() {
		return enemyBulletSpeedBox;
	}

	public void setEnemyBulletSpeedBox(JComboBox<String> enemyBulletSpeedBox) {
		this.enemyBulletSpeedBox = enemyBulletSpeedBox;
	}

	public JComboBox<String> getEnemyBulletTimeBox() {
		return enemyBulletTimeBox;
	}

	public void setEnemyBulletTimeBox(JComboBox<String> enemyBulletTimeBox) {
		this.enemyBulletTimeBox = enemyBulletTimeBox;
	}

	public JComboBox<String> getPlayerBulletSpeedBox() {
		return playerBulletSpeedBox;
	}

	public void setPlayerBulletSpeedBox(JComboBox<String> playerBulletSpeedBox) {
		this.playerBulletSpeedBox = playerBulletSpeedBox;
	}

	public JTextField getEnemyCountText() {
		return enemyCountText;
	}

	public void setEnemyCountText(JTextField enemyCountText) {
		this.enemyCountText = enemyCountText;
	}

	public JLabel getLevelLabel() {
		return levelLabel;
	}

	public void setLevelLabel(JLabel levelLabel) {
		this.levelLabel = levelLabel;
	}

	public JLabel getEnemySpeedLabel() {
		return enemySpeedLabel;
	}

	public void setEnemySpeedLabel(JLabel enemySpeedLabel) {
		this.enemySpeedLabel = enemySpeedLabel;
	}

	public JLabel getEnemyBulletSpeedLabel() {
		return enemyBulletSpeedLabel;
	}

	public void setEnemyBulletSpeedLabel(JLabel enemyBulletSpeedLabel) {
		this.enemyBulletSpeedLabel = enemyBulletSpeedLabel;
	}

	public JLabel getEnemyBulletTimeLabel() {
		return enemyBulletTimeLabel;
	}

	public void setEnemyBulletTimeLabel(JLabel enemyBulletTimeLabel) {
		this.enemyBulletTimeLabel = enemyBulletTimeLabel;
	}

	public JLabel getPlayerBulletSpeedLabel() {
		return playerBulletSpeedLabel;
	}

	public void setPlayerBulletSpeedLabel(JLabel playerBulletSpeedLabel) {
		this.playerBulletSpeedLabel = playerBulletSpeedLabel;
	}

	public JLabel getEnemyCountLabel() {
		return enemyCountLabel;
	}

	public void setEnemyCountLabel(JLabel enemyCountLabel) {
		this.enemyCountLabel = enemyCountLabel;
	}

	public JButton getSureBtn() {
		return sureBtn;
	}

	public void setSureBtn(JButton sureBtn) {
		this.sureBtn = sureBtn;
	}

	public JButton getCancelBtn() {
		return cancelBtn;
	}

	public void setCancelBtn(JButton cancelBtn) {
		this.cancelBtn = cancelBtn;
	}

	public ButtonGroup getGroup() {
		return group;
	}

	public void setGroup(ButtonGroup group) {
		this.group = group;
	}

}
