package ui;

import java.awt.Graphics;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

import util.Data;

public class ExplainPanel extends JPanel {
	
	
	
	public ExplainPanel() {
		
		// 绝对布局
		this.setLayout(null);
		
	}

	public void paintComponent(Graphics g) {
		
		// 必须调用此方法
		super.paintComponent(g);
		//画道具说明
		g.drawImage(Data.IMG_EXPLAIN, 0, 0, 500, 500, 0, 0, 500, 500, null);
		
		//刷新画板
		this.repaint();
	}
}
