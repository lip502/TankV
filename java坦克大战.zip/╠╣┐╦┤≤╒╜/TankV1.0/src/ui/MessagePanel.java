package ui;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

import javax.swing.JPanel;

import util.Data;

public class MessagePanel extends JPanel {
	
	

	public MessagePanel() {

		// 绝对布局
		this.setLayout(null);
		
	}

	public void paintComponent(Graphics g) {

		// 必须调用此方法
		super.paintComponent(g);
		//画图
		g.drawImage(Data.IMGMESSAGE_BG, 0, 0, 200, 600, 0, 0, 200, 600, null);
		//改变画笔颜色
		g.setColor(Color.RED);
		//改变字体形态
		g.setFont(new Font("楷体", Font.PLAIN, 30));
		
		
		//画黄色未出现敌人
		g.drawString(Data.yellowEnemyCount+"", 140, 82);
		//画粉色未出现敌人
		g.drawString(Data.pinkEnemyCount+"", 140, 140);
		//画绿色未出现敌人
		g.drawString(Data.pinkEnemyCount+"", 140, 195);
		
		//改变字体形态
		g.setFont(new Font("楷体", Font.PLAIN ,23));
		
		//改变画笔颜色
		g.setColor(Color.YELLOW);
		
		//画玩家名字
		g.drawString(Data.playerName, 100, 421);
		
		//改变画笔颜色
		g.setColor(Color.GREEN);
		//画玩家生命
		g.drawString(Data.playerLife+"", 130, 464);
		
		//画当前关卡
		g.drawString(Data.nowLevel+"", 130, 500);
		
		//画当前击杀
		g.drawString(Data.nowHit+"", 130, 536);
		
		//画当前得分
		g.drawString(Data.nowScore+"",130,576);
		
		
		
		//刷新画板
		this.repaint();

	}

}
