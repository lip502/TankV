package ui;

import javax.swing.JFrame;

public class DiyFrame extends JFrame {

	private DiyPanel dip = new DiyPanel();

	public DiyFrame() {

		// 绝对布局
		this.setLayout(null);

		// 标题
		this.setTitle("自定义游戏");
		// 大小
		this.setSize(300, 340);
		// 不可拉伸
		this.setResizable(false);
		// 关闭 直接关闭本窗口
		this.setDefaultCloseOperation(1);

		// 添加面板
		dip.setBounds(0, 0, 300, 340);
		this.add(dip);

		// 居中
		this.setLocationRelativeTo(null);

	}

	public DiyPanel getDip() {
		return dip;
	}

	public void setDip(DiyPanel dip) {
		this.dip = dip;
	}

}
