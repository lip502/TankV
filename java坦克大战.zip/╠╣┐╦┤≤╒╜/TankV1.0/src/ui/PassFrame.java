package ui;

import javax.swing.JDialog;

public class PassFrame extends JDialog {
	
	//创建计分面板
	PassPanel pp = new PassPanel();
	
	public PassFrame() {
		
		
		// 绝对布局
		this.setLayout(null);
		
		// 标题
		this.setTitle("统计分数");
		// 尺寸
		this.setSize(436, 429);
		// 不可改变大小
		this.setResizable(false);
		
		//加入面板
		this.add(pp);
		pp.setBounds(0, 0, 430, 400);
		
		// 居中
		this.setLocationRelativeTo(null);
		
		
	}

	public PassPanel getPp() {
		return pp;
	}

	public void setPp(PassPanel pp) {
		this.pp = pp;
	}

	
}
