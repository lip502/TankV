package ui;

import javax.swing.JDialog;

public class ExplainFrame extends JDialog {
	
	private ExplainPanel ep = new ExplainPanel();

	public ExplainFrame() {

		// 绝对布局
		this.setLayout(null);

		// 标题
		this.setTitle("道具说明");
		// 尺寸
		this.setSize(506, 528);
		// 不可改变大小
		this.setResizable(false);

		// 加入面板
		this.add(ep);
		ep.setBounds(0, 0, 500, 500);

		// 居中
		this.setLocationRelativeTo(null);

	}

	public ExplainPanel getEp() {
		return ep;
	}

	public void setEp(ExplainPanel ep) {
		this.ep = ep;
	}

}
