package ui;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.text.StyledEditorKit.ForegroundAction;

import model.Atlas;
import model.Enemy;
import model.EnemyBullet;
import model.PlayerBullet;
import model.function.FunctionPackage;
import util.Data;
import util.DataMap;

public class GamePanel extends JPanel {

	// 通关图片
	JLabel passLabel = new JLabel(new ImageIcon("img/victory.jpg"));

	// 游戏结束图片
	JLabel overLabel = new JLabel(new ImageIcon("img/gameover.png"));

	// 老家爆炸图片
	JLabel badLabel = new JLabel(new ImageIcon("img/badhome.png"));

	public GamePanel() {
		// 设置颜色
		this.setBackground(Color.black);
		// 绝对布局
		this.setLayout(null);

	}

	public void paintComponent(Graphics g) {

		// 必须调用此方法
		super.paintComponent(g);

		// 当游戏开始才画玩家
		if (Data.gameStart == true) {

			// 画玩家
			Data.player.drawMe(g);

		}
		// 画地形
		drawAtlas(g);

		// 画玩家子弹
		drawPlayerBullet(g);

		// 画敌人
		drawEnemy(g);

		// 画敌人子弹
		drawEnemyBullet(g);

		// 画功能包
		drawPackge(g);
		

		// 画游戏结束图片和爆炸老家图片
		if (Data.gameOver == true) {

			overLabel.setBounds(150, 176, 300, 248);
			// 画游戏老巢爆炸
			badLabel.setBounds(280, 560, Data.PLAYER_SIZE, Data.PLAYER_SIZE);

			this.add(overLabel);

			this.add(badLabel);

		} else {
			// 移除图片
			this.remove(overLabel);

			this.remove(badLabel);

		}

		if (Data.lastLevel == true) {

			// 加入通关图片

			passLabel.setBounds(0, 0, 600, 600);
			// 加入图片
			this.add(passLabel);

		} else {
			// 移除图片
			this.remove(passLabel);
		}

		// 刷新画板
		this.repaint();

	}

	// 画玩家子弹的方法
	public void drawPlayerBullet(Graphics g) {

		for (int i = 0; i < Data.pBulletList.size(); i++) {

			PlayerBullet pb = Data.pBulletList.get(i);

			pb.drawMe(g);
		}
	}

	// 画敌人的方法
	public void drawEnemy(Graphics g) {

		for (int i = 0; i < Data.enlist.size(); i++) {

			Enemy en = Data.enlist.get(i);

			en.drawMe(g);
		}

	}

	// 画地形的方法
	public void drawAtlas(Graphics g) {

		for (int i = 0; i < DataMap.atlist.size(); i++) {

			Atlas at = DataMap.atlist.get(i);

			at.drawMe(g);

		}

	}

	// 画敌人子弹的方法
	public void drawEnemyBullet(Graphics g) {

		for (int i = 0; i < Data.enBulletList.size(); i++) {

			EnemyBullet enbu = Data.enBulletList.get(i);

			enbu.drawMe(g);
		}
	}

	// 画功能包的方法
	public void drawPackge(Graphics g) {

		for (int i = 0; i < Data.PackageList.size(); i++) {

			FunctionPackage fp = Data.PackageList.get(i);

			fp.drawMe(g);

		}

	}

	public JLabel getPassLabel() {
		return passLabel;
	}

	public void setPassLabel(JLabel passLabel) {
		this.passLabel = passLabel;
	}

}
