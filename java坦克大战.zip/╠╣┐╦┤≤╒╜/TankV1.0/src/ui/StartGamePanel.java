package ui;

import java.awt.Graphics;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;

import util.Data;

public class StartGamePanel extends JPanel {

	// 开始游戏按钮
	private JButton startBtn = new JButton(new ImageIcon("img/startbtn.png"));
	// 退出游戏按钮
	private JButton exitBtn = new JButton(new ImageIcon("img/exitbtn.png"));

	public StartGamePanel() {

		// 绝对布局
		this.setLayout(null);

		// 设置透明
		startBtn.setContentAreaFilled(false);
		// 设置按钮的位置和添加到面板
		startBtn.setBounds(333, 350, 135, 45);
		this.add(startBtn);

		// 设置透明
		exitBtn.setContentAreaFilled(false);
		exitBtn.setBounds(333, 440, 135, 45);
		this.add(exitBtn);

		// 创建动作监听
		startBtn.setActionCommand("start");

		exitBtn.setActionCommand("exit");

	}

	public void paintComponent(Graphics g) {

		// 必须调用此方法
		super.paintComponent(g);

		g.drawImage(Data.IMGSTART_BG, 0, 0, 806, 652, 0, 0, 806, 652, null);
		// 刷新画板
		this.repaint();

	}

	public JButton getStartbtn() {
		return startBtn;
	}

	public void setStartbtn(JButton startbtn) {
		this.startBtn = startbtn;
	}

	public JButton getExitbtn() {
		return exitBtn;
	}

	public void setExitbtn(JButton exitbtn) {
		this.exitBtn = exitbtn;
	}

}
