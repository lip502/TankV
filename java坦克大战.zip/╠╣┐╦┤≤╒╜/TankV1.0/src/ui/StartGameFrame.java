package ui;

import javax.swing.JFrame;
import thread.MediaPlayer;
import util.Data;
import listener.DiyListener;
import listener.MenuBarListener;
import listener.PlayerListener;
import listener.StartGameFrameListener;
import listener.StartPanelBtnListener;


public class StartGameFrame extends JFrame {

	// 创建开始游戏的面板
	private StartGamePanel sgp = new StartGamePanel();

	// 创建游戏窗口
	private GameFrame gf = new GameFrame();

	// 创建过关窗口
	private PassFrame pf = new PassFrame();
	
	//创建说明窗口
	private ExplainFrame ef = new ExplainFrame();

	// 创建开始窗口的窗口监听
	private StartGameFrameListener sgfl = new StartGameFrameListener(this);

	// 创建开始游戏面板上两个按钮的监听
	private StartPanelBtnListener spbl = new StartPanelBtnListener(this);
	// 创建游戏窗口菜单栏监听
	private MenuBarListener menuls = new MenuBarListener(this);
	// 创建玩家移动的监听
	private PlayerListener playmovelist = new PlayerListener(this);

	//创建自定义窗口
	private DiyFrame dif = new DiyFrame();
	//创建自定义窗口监听
	private DiyListener dlst = new DiyListener(this);
	
	//背景音乐线程
	private Thread backgroundThread;

	public StartGameFrame() {

		// 绝对布局
		this.setLayout(null);

		// 标题
		this.setTitle("坦克大战V1.0");
		// 尺寸
		this.setSize(806, 652);
		// 不可改变大小
		this.setResizable(false);
		// 默认关闭方式为什么都不干
		this.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		// 添加开始游戏的面板
		this.add(sgp);
		sgp.setBounds(0, 0, 806, 652);

		// 给开始游戏界面两个按钮添加动作监听
		this.getSgp().getStartbtn().addActionListener(spbl);
		this.getSgp().getExitbtn().addActionListener(spbl);

		// 给过关面板上的三个按钮添加动作监听
		this.getPf().getPp().getExitGameBtn().addActionListener(spbl);
		this.getPf().getPp().getNextLevel().addActionListener(spbl);
		this.getPf().getPp().getResGame().addActionListener(spbl);

		// 调用给菜单添加监听的方法
		initBar();

		// 添加开始窗口监听
		this.addWindowListener(sgfl);
		
		//给自定义窗口按钮添加动作监听/
		this.getDif().getDip().getSelfDefineGame().addActionListener(dlst);
		this.getDif().getDip().getNormalGame().addActionListener(dlst);
		this.getDif().getDip().getCancelBtn().addActionListener(dlst);
		this.getDif().getDip().getSureBtn().addActionListener(dlst);
		
		// 播放背景音乐
			backgroundThread = new Thread(new MediaPlayer(Data.PLAY_STARTCARTOON));
			
			backgroundThread.start();
		
		// 居中
		this.setLocationRelativeTo(null);
	}

	public StartGameFrameListener getSgfl() {
		return sgfl;
	}

	public void setSgfl(StartGameFrameListener sgfl) {
		this.sgfl = sgfl;
	}

	public StartGamePanel getSgp() {
		return sgp;
	}

	public void setSgp(StartGamePanel sgp) {
		this.sgp = sgp;
	}

	public GameFrame getGf() {
		return gf;
	}

	public void setGf(GameFrame gf) {
		this.gf = gf;
	}

	public MenuBarListener getMenuls() {
		return menuls;
	}

	public void setMenuls(MenuBarListener menuls) {
		this.menuls = menuls;
	}

	// 给菜单添加监听的方法
	public void initBar() {

		// 给游戏窗口菜单添加监听
		this.getGf().getStart().addActionListener(menuls);
		this.getGf().getRestart().addActionListener(menuls);
		this.getGf().getDiy().addActionListener(menuls);
		this.getGf().getPauseGame().addActionListener(menuls);
		this.getGf().getConGame().addActionListener(menuls);
		this.getGf().getExit().addActionListener(menuls);
		this.getGf().getAbout().addActionListener(menuls);
		this.getGf().getExplian().addActionListener(menuls);

	}

	public PlayerListener getPlaymovelist() {
		return playmovelist;
	}

	public void setPlaymovelist(PlayerListener playmovelist) {
		this.playmovelist = playmovelist;
	}

	public PassFrame getPf() {
		return pf;
	}

	public void setPf(PassFrame pf) {
		this.pf = pf;
	}

	public DiyFrame getDif() {
		return dif;
	}

	public void setDif(DiyFrame dif) {
		this.dif = dif;
	}

	public StartPanelBtnListener getSpbl() {
		return spbl;
	}

	public void setSpbl(StartPanelBtnListener spbl) {
		this.spbl = spbl;
	}

	public DiyListener getDlst() {
		return dlst;
	}

	public void setDlst(DiyListener dlst) {
		this.dlst = dlst;
	}

	public Thread getBackgroundThread() {
		return backgroundThread;
	}

	public void setBackgroundThread(Thread backgroundThread) {
		this.backgroundThread = backgroundThread;
	}

	public ExplainFrame getEf() {
		return ef;
	}

	public void setEf(ExplainFrame ef) {
		this.ef = ef;
	}

	
}
