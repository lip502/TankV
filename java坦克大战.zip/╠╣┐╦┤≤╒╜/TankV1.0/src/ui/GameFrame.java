package ui;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

import listener.GameWindowListener;

public class GameFrame extends JFrame {
	
	//创建游戏窗口监听
	private GameWindowListener gwl = new GameWindowListener(this);

	// 创建游戏面板
	private GamePanel gp = new GamePanel();
	
	//创建信息面板
	private MessagePanel messp = new MessagePanel();

	// 创建菜单栏
	private JMenuBar bar = new JMenuBar();
	//创建菜单
	private JMenu game;

	private JMenu help;
	//创建菜单项  开始
	private JMenuItem start;
	//重新开始
	private JMenuItem restart;
	//自定义
	private JMenuItem diy;
	//暂停游戏
	private JMenuItem pauseGame;
	//继续游戏
	private JMenuItem conGame;
	//退出游戏
	private JMenuItem exit;
	//关于游戏
	private JMenuItem about;
	//操作指南
	private JMenuItem explian;

	public GameFrame() {

		// 绝对布局
		this.setLayout(null);

		// 标题
		this.setTitle("坦克大战V1.0");
		// 尺寸
		this.setSize(806, 652);
		// 不可改变大小
		this.setResizable(false);
		// 默认关闭方式为什么都不干
		this.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		// 添加游戏的面板
		this.add(gp);
		//设置位置大小
		gp.setBounds(0, 0, 600, 600);
		//添加信息面板
		this.add(messp);
		messp.setBounds(600,0,200,600);

		// 调用初始化按钮的方法
		initBar();

		// 居中
		this.setLocationRelativeTo(null);
		//添加窗口监听
		this.addWindowListener(gwl);

		// 给按钮创建动作监听
		start.setActionCommand("starts");
		restart.setActionCommand("restart");
		diy.setActionCommand("diy");
		exit.setActionCommand("exitt");
		about.setActionCommand("about");
		pauseGame.setActionCommand("pauseGame");
		conGame.setActionCommand("conGame");
		explian.setActionCommand("explian");

	}

	public void initBar() {

		game = new JMenu("游戏");

		help = new JMenu("帮助");

		start = new JMenuItem("开始游戏");

		restart = new JMenuItem("重新开始");
		
		pauseGame = new JMenuItem("暂停");
		
		conGame = new JMenuItem("继续");
		
		diy = new JMenuItem("自定义");

		exit = new JMenuItem("退出游戏");
		
		explian = new JMenuItem("游戏说明");

		about = new JMenuItem("关于");
		
		// 设置按钮一开始不可用
		restart.setEnabled(false);
		pauseGame.setEnabled(false);
		conGame.setEnabled(false);
		diy.setEnabled(false);

		// 加入游戏菜单
		game.add(start);
		game.add(restart);
		game.add(pauseGame);
		game.add(conGame);
		game.add(diy);
		game.add(exit);
		// 加入帮助菜单
		help.add(explian);
		help.add(about);
		// 将菜单加入菜单栏
		bar.add(game);
		bar.add(help);

		this.setJMenuBar(bar);
	}

	public GamePanel getGp() {
		return gp;
	}

	public void setGp(GamePanel gp) {
		this.gp = gp;
	}

	public JMenuBar getBar() {
		return bar;
	}

	public void setBar(JMenuBar bar) {
		this.bar = bar;
	}

	public JMenu getGame() {
		return game;
	}

	public void setGame(JMenu game) {
		this.game = game;
	}

	public JMenu getHelp() {
		return help;
	}

	public void setHelp(JMenu help) {
		this.help = help;
	}

	public JMenuItem getStart() {
		return start;
	}

	public void setStart(JMenuItem start) {
		this.start = start;
	}

	public JMenuItem getRestart() {
		return restart;
	}

	public void setRestart(JMenuItem restart) {
		this.restart = restart;
	}

	public JMenuItem getExit() {
		return exit;
	}

	public void setExit(JMenuItem exit) {
		this.exit = exit;
	}

	public JMenuItem getAbout() {
		return about;
	}

	public void setAbout(JMenuItem about) {
		this.about = about;
	}

	public JMenuItem getDiy() {
		return diy;
	}

	public void setDiy(JMenuItem diy) {
		this.diy = diy;
	}

	public JMenuItem getExplian() {
		return explian;
	}

	public void setExplian(JMenuItem explian) {
		this.explian = explian;
	}

	public GameWindowListener getGwl() {
		return gwl;
	}

	public void setGwl(GameWindowListener gwl) {
		this.gwl = gwl;
	}

	public MessagePanel getMessp() {
		return messp;
	}

	public void setMessp(MessagePanel messp) {
		this.messp = messp;
	}

	public JMenuItem getPauseGame() {
		return pauseGame;
	}

	public void setPauseGame(JMenuItem pauseGame) {
		this.pauseGame = pauseGame;
	}

	public JMenuItem getConGame() {
		return conGame;
	}

	public void setConGame(JMenuItem conGame) {
		this.conGame = conGame;
	}

}
