package util;

import java.awt.Image;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.ImageIcon;

import model.Atlas;
import model.Enemy;
import model.EnemyBullet;
import model.GreenEnemy;
import model.PinkEnemy;
import model.Player;
import model.PlayerBullet;
import model.YellowEnemy;
import model.function.FunctionPackage;

public class Data {

	// 玩家名字
	public static String playerName = null;
	// 玩家方向
	public static int playerDirection = 1;
	// 玩家移动
	public static int playerMove = 0;
	// 构建玩家
	public static Player player = new Player(200, 560);
	// 玩家子弹移动线程的休眠
	public static int playerBulletSleep = 20;
	// 敌人移动的步数
	public static int enemyStep = 5;
	// 敌人移动的速度
	public static int enemyMoveSpeed = 30;
	// 敌人发射子弹的频率
	public static int enemyBulletTime = 1000;
	// 敌人子弹移动速度
	public static int enemyBulletSpeed = 20;

	// 未出现敌人总数
	public static int EnemyCount = 20;
	// 未出现
	// 黄色敌人数量
	public static int yellowEnemyCount = 0;
	// 粉色敌人数量
	public static int pinkEnemyCount = 0;
	// 绿色敌人数量
	public static int greenEnemyCount = 0;

	// 击杀黄色敌人数量
	public static int hitYellowEnemyCount = 0;
	// 击杀粉色敌人数量
	public static int hitPinkEnemyCount = 0;
	// 击杀绿色敌人数量
	public static int hitGreenEnemyCount = 0;

	// 玩家生命
	public static int playerLife = 3;
	// 当前关卡
	public static int nowLevel = 1;
	// 本关击杀
	public static int nowHit = 0;
	// 本关得分
	public static int nowScore = 0;

	// 计分线程休眠时间
	public static int passLevelTime = 500;

	// 游戏结束
	public static boolean gameOver = false;

	// 控制过关弹窗
	public static boolean victoryFlag = true;

	// 设置游戏暂停
	public static boolean gamePause = false;

	// 设置游戏开始
	public static boolean gameStart = false;

	// 设置结束图片
	public static boolean lastLevel = false;

	// 是否可以打铁
	public static boolean hitSteels = false;

	// 时间暂停
	public static boolean pauseTime = false;
	
	//画说明图
	public static boolean aboutJpg= false;

	// 玩家尺寸
	public static final int PLAYER_SIZE = 40;
	// 血条向上距离
	public static final int HP_UP = 42;
	// 血条向下距离
	public static final int HP_DOWN = 7;
	// 血条高度
	public static final int HP_H = 5;

	// 血条高度
	public static final int GAMEBG_SIZE = 600;

	// 子弹尺寸
	public static final int BULLET_SIZE = 10;

	// 功能包尺寸
	public static final int PACKGE_SIZE = 30;

	// 创建玩家子弹集合
	public static ArrayList<PlayerBullet> pBulletList = new ArrayList<PlayerBullet>();

	// 创建前台敌人集合
	public static ArrayList<Enemy> enlist = new ArrayList<Enemy>();

	// 创建后台敌人集合
	public static ArrayList<Enemy> backEnlist = new ArrayList<Enemy>();

	// 创建敌人子弹集合
	public static ArrayList<EnemyBullet> enBulletList = new ArrayList<EnemyBullet>();

	// 创建功能包集合
	public static ArrayList<FunctionPackage> PackageList = new ArrayList<FunctionPackage>();

	// 画开始游戏的背景图
	public static final Image IMGSTART_BG = new ImageIcon("img/startBg.jpg").getImage();
	// 画游戏信息面板
	public static final Image IMGMESSAGE_BG = new ImageIcon("img/message.jpg").getImage();
	// 画玩家
	public static final Image IMGPLAYER = new ImageIcon("img/player.png").getImage();
	// 画子弹
	public static final Image IMGBULLET = new ImageIcon("img/bullet.png").getImage();
	// 画黄色敌人
	public static final Image IMG_YELLOWENEMY = new ImageIcon("img/yellowenemy.png").getImage();
	// 画黄色敌人
	public static final Image IMG_PINKENEMY = new ImageIcon("img/pinkenemy.png").getImage();
	// 画黄色敌人
	public static final Image IMG_GREENENEMY = new ImageIcon("img/greenenemy.png").getImage();
	// 画敌人子弹
	public static final Image IMG_ENEMYBULLET = new ImageIcon("img/enemyBullet.png").getImage();
	// 画过关面板图
	public static final Image IMG_PASS = new ImageIcon("img/pass.jpg").getImage();
	
	//画操作说明图
	public static final Image IMG_EXPLAIN = new ImageIcon("img/about.jpg").getImage();

	// 道具功能包
	// 血量包
	public static final Image HP_IMG = new ImageIcon("img/hp.png").getImage();
	// 打铁
	public static final Image HITSTEEL_IMG = new ImageIcon("img/hitsteel.png").getImage();
	// 铁墙壁
	public static final Image STEELWALL_IMG = new ImageIcon("img/steelwall.png").getImage();
	// 生命
	public static final Image LIFE_IMG = new ImageIcon("img/life.png").getImage();
	// 定时
	public static final Image PAUSETIME_IMG = new ImageIcon("img/pausetime.png").getImage();

	// 音乐
	/** 选择音效文件地址 */
	public final static String PLAY_MENU = "audio/menu.wav";

	/** 碰撞音效文件地址 */
	public final static String PLAY_HIT = "audio/hit.wav";

	/** 爆炸音乐文件地址 */
	public final static String PLAY_BOOM = "audio/boom.wav";

	/** 进入游戏片头音乐文件地址 */
	public final static String PLAY_ENTERGAME = "audio/start.wav";

	/** 开火音乐文件地址 */
	public final static String PLAY_FIRE = "audio/fire.wav";

	/** 片头动画音乐文件地址 */
	public final static String PLAY_STARTCARTOON = "audio/startCartoonMusic.wav";

	// 初始化敌人的方法
	public static void initEnemy() {

		for (int i = 0; i < EnemyCount; i++) {
			// 类型
			int type = new Random().nextInt(3);
			// 出现的地点
			int appear = new Random().nextInt(3);
			// 定义xy坐标
			int xp = 0;

			int yp = 0;
			// 随机出现
			if (appear == 0) {

				xp = 0;

				yp = 0;

			} else if (appear == 1) {

				xp = 280;

				yp = 0;

			} else {

				xp = 560;

				yp = 0;

			}
			// 随机添加敌人到集合
			if (type == 0) {
				// 生成黄色敌人加入集合
				Enemy en = new YellowEnemy(xp, yp);

				backEnlist.add(en);

				yellowEnemyCount++;

				hitYellowEnemyCount++;

			} else if (type == 1) {
				// 生成粉色敌人加入集合
				Enemy en = new PinkEnemy(xp, yp);

				backEnlist.add(en);

				pinkEnemyCount++;

				hitPinkEnemyCount++;

			} else {
				// 生成绿色敌人加入集合
				Enemy en = new GreenEnemy(xp, yp);

				backEnlist.add(en);

				greenEnemyCount++;

				hitGreenEnemyCount++;
			}

		}

	}

}
