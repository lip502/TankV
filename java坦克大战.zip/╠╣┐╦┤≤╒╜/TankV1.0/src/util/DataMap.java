package util;

import java.awt.Image;
import java.util.ArrayList;

import javax.swing.ImageIcon;

import model.Atlas;
import model.Grass;
import model.Home;
import model.Steels;
import model.Walls;
import model.Water;

public class DataMap {
	
	//创建后台地形集合
	public static ArrayList<Atlas> backAtlist = new ArrayList<Atlas>();
	
	//创建前台地形集合
	public static ArrayList<Atlas> atlist = new ArrayList<Atlas>();

	// 画草
	public static final Image IMG_GRASS = new ImageIcon("img/grass.png").getImage();
	// 画水
	public static final Image IMG_WATER = new ImageIcon("img/water.png").getImage();
	// 画墙
	public static final Image IMG_WALLS = new ImageIcon("img/walls.png").getImage();
	//画铁墙
	public static final Image IMG_STEELS = new ImageIcon("img/steels.png").getImage();
	//画老巢
	public static final Image IMG_HOME = new ImageIcon("img/home.png").getImage();


	public static void FirstMap() {
		//地形1
		int[][] mapArray = {
				{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
				{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
				{0, 0, 0, 0, 0, 0, 2, 2, 2, 0, 0, 0, 0, 0, 0},
				{0, 0, 0, 0, 0, 2, 2, 2, 2, 2, 0, 0, 0, 0, 0},
				{0, 0, 0, 0, 2, 2, 2, 2, 2, 2, 2, 0, 0, 0, 0},
				{0, 0, 0, 0, 2, 2, 1, 2, 1, 2, 2, 0, 0, 0, 0},
				{0, 0, 0, 0, 2, 1, 1, 2, 1, 1, 2, 0, 0, 0, 0},
				{0, 0, 0, 0, 2, 2, 2, 2, 2, 2, 2, 0, 0, 0, 0},
				{0, 0, 0, 0, 0, 2, 1, 2, 1, 2, 0, 0, 0, 0, 0},
				{0, 0, 0, 0, 0, 2, 2, 2, 2, 2, 0, 0, 0, 0, 0},
				{3, 3, 3, 0, 0, 0, 2, 0, 2, 0, 0, 0, 3, 3, 3},
				{1, 0, 0, 0, 0, 2, 0, 2, 0, 2, 0, 0, 0, 0, 1},
				{1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1},
				{0, 1, 0, 1, 0, 0, 2, 2, 2, 0, 0, 1, 0, 1, 0},
				{4, 0, 4, 0, 4, 0, 2, 5, 2, 0, 4, 0, 4, 0, 4},	
		};
		
		for (int i = 0; i < mapArray.length; i++) {
		
			for (int j = 0; j < mapArray[i].length; j++) {
				
				switch(mapArray[j][i]){
				case 1 : 
					backAtlist.add(new Grass(i * 40, j * 40));    
					break;
				case 2 : 
					backAtlist.add(new Walls(i * 40, j * 40));   
					break;
				case 3 : 
					backAtlist.add(new Water(i * 40, j * 40));  
					break;
				case 4 : 
					backAtlist.add(new Steels(i * 40, j * 40)); 
					break;
				case 5 : 
					backAtlist.add(new Home(i * 40, j * 40)); 
					break;
			}
					
		}
			
	}
}	
		public static void SecondMap(){
			//地形2
			int[][] mapArray = {
					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
					{0, 2, 0, 1, 1, 1, 1, 0, 3, 0, 4, 4, 4, 4, 0},
					{0, 2, 0, 1, 0, 0, 1, 0, 3, 0, 4, 0, 0, 4, 0},
					{0, 2, 0, 1, 0, 0, 1, 0, 3, 0, 4, 0, 0, 4, 0},
					{0, 2, 0, 1, 0, 0, 1, 0, 3, 0, 4, 0, 0, 4, 0},
					{0, 2, 0, 1, 1, 1, 1, 0, 3, 0, 4, 0, 0, 4, 0},
					{0, 2, 0, 0, 0, 0, 1, 0, 3, 0, 4, 0, 0, 4, 0},
					{0, 2, 0, 0, 0, 0, 1, 0, 3, 0, 4, 0, 0, 4, 0},
					{0, 2, 0, 0, 0, 0, 1, 0, 3, 0, 4, 0, 0, 4, 0},
					{0, 2, 0, 1, 1, 1, 1, 0, 3, 0, 4, 4, 4, 4, 0},
					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
					{0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0},
					{0, 0, 0, 0, 0, 0, 1, 5, 1, 0, 0, 0, 0, 0, 0}
			};
			
			//遍历数组 根据数字进行创建地图		
			for(int i = 0; i < mapArray.length; i++){
				for(int j = 0; j < mapArray[i].length; j++){
					
					switch(mapArray[j][i]){
						case 1 : 
							backAtlist.add(new Walls(i * 40, j * 40));    
							break;
						case 2 : 
							backAtlist.add(new Steels(i * 40, j * 40));   
							break;
						case 3 : 
							backAtlist.add(new Grass(i * 40, j * 40));  
							break;
						case 4 : 
							backAtlist.add(new Water(i * 40, j * 40)); 
							break;
						case 5 : 
							backAtlist.add(new Home(i * 40, j * 40)); 
							break;
					}
				}
			}
		}
		public static void ThirdMap(){
			//地形3
			int[][] mapArray = {
					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
					{0, 2, 2, 2, 0, 3, 3, 3, 0, 1, 1, 1, 0, 4, 0},
					{0, 0, 0, 2, 0, 3, 0, 3, 0, 0, 0, 1, 0, 4, 0},
					{0, 0, 0, 2, 0, 3, 0, 3, 0, 0, 0, 1, 0, 4, 0},
					{0, 2, 2, 2, 0, 3, 0, 3, 0, 1, 1, 1, 0, 4, 0},
					{0, 2, 0, 0, 0, 3, 0, 3, 0, 1, 0, 0, 0, 4, 0},
					{0, 2, 0, 0, 0, 3, 0, 3, 0, 1, 0, 0, 0, 4, 0},
					{0, 2, 2, 2, 0, 3, 3, 3, 0, 1, 1, 1, 0, 4, 0},
					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
					{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
					{0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0},
					{0, 0, 0, 0, 0, 0, 1, 5, 1, 0, 0, 0, 0, 0, 0}
			};
			
			//遍历数组 根据数字进行创建地图		
			for(int i = 0; i < mapArray.length; i++){
				for(int j = 0; j < mapArray[i].length; j++){
					
					switch(mapArray[j][i]){
						case 1 : 
							backAtlist.add(new Walls(i * 40, j * 40));    
							break;
						case 2 : 
							backAtlist.add(new Steels(i * 40, j * 40));   
							break;
						case 3 : 
							backAtlist.add(new Grass(i * 40, j * 40));  
							break;
						case 4 : 
							backAtlist.add(new Water(i * 40, j * 40)); 
							break;
						case 5 : 
							backAtlist.add(new Home(i * 40, j * 40)); 
							break;
					}
				}
			}
		}

}

