package listener;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JOptionPane;

import ui.GameFrame;

public class GameWindowListener extends WindowAdapter {
	
	private GameFrame f;
	
	public GameWindowListener(GameFrame f) {
		
		this.f = f;
				
	}
	
	@Override
	public void windowClosing(WindowEvent e) {

		// 弹窗
		int key = JOptionPane.showConfirmDialog(f, "确定要退出游戏吗？", "退出游戏", JOptionPane.OK_CANCEL_OPTION);

		if (key == JOptionPane.OK_OPTION) {

			// 关闭窗口
			System.exit(0);

		}
	}

}
