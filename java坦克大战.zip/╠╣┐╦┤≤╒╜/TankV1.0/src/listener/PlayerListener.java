package listener;

import java.awt.Rectangle;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

import org.omg.CORBA.DATA_CONVERSION;

import model.Atlas;
import model.Enemy;
import model.Home;
import model.Player;
import model.PlayerBullet;
import model.Steels;
import model.Walls;
import model.Water;
import thread.MediaPlayer;
import ui.StartGameFrame;
import util.Data;
import util.DataMap;

public class PlayerListener extends KeyAdapter {

	private StartGameFrame f;

	// 暂停图片
	JLabel pauseLabel = new JLabel(new ImageIcon("img/pause.png"));

	public PlayerListener(StartGameFrame f) {

		this.f = f;
	}

	@Override
	public void keyPressed(KeyEvent e) {

		// 定义变量
		boolean flag = false;

		// 判断是哪个按键
		int key = e.getKeyCode();

		if (key == KeyEvent.VK_W) {

			if (Data.gamePause == false) {

				// 设置刚开始可以正常移动
				flag = true;

				Data.playerDirection = 1;

				for (int i = 0; i < Data.enlist.size(); i++) {

					Enemy en = Data.enlist.get(i);

					// 矩形判断
					Rectangle enRect = new Rectangle(en.getXp(), en.getYp(), Data.PLAYER_SIZE, Data.PLAYER_SIZE);

					// 玩家矩形
					Rectangle plRect = new Rectangle(Data.player.getXp(), Data.player.getYp() - 5, Data.PLAYER_SIZE,
							Data.PLAYER_SIZE);
					// 如果碰撞
					if (enRect.intersects(plRect) == true) {

						flag = false;

					}

				}

				for (int i = 0; i < DataMap.atlist.size(); i++) {

					Atlas at = DataMap.atlist.get(i);

					// 矩形判断
					Rectangle atRect = new Rectangle(at.getXp(), at.getYp(), Data.PLAYER_SIZE, Data.PLAYER_SIZE);

					// 玩家矩形
					Rectangle plRect = new Rectangle(Data.player.getXp(), Data.player.getYp() - 5, 38, 38);
					// 如果碰撞
					if (plRect.intersects(atRect)) {
						// 如果是碰到墙
						if (at instanceof Walls) {

							flag = false;
							// 如果碰到水
						} else if (at instanceof Water) {

							flag = false;
							// 如果碰到铁
						} else if (at instanceof Steels) {

							flag = false;
							// 如果碰到老巢
						} else if (at instanceof Home) {

							flag = false;

						}

					}

				}

				if (flag == true) {

					Data.playerMove = 1;
					Data.player.playerMove();
				}

			}

		} else if (key == KeyEvent.VK_S) {

			if (Data.gamePause == false) {

				flag = true;

				Data.playerDirection = 2;

				for (int i = 0; i < Data.enlist.size(); i++) {

					Enemy en = Data.enlist.get(i);

					// 矩形判断
					Rectangle enRect = new Rectangle(en.getXp(), en.getYp(), Data.PLAYER_SIZE, Data.PLAYER_SIZE);

					// 玩家矩形
					Rectangle plRect = new Rectangle(Data.player.getXp(), Data.player.getYp() + 5, Data.PLAYER_SIZE,
							Data.PLAYER_SIZE);
					// 如果碰撞
					if (enRect.intersects(plRect) == true) {

						flag = false;

					}

				}

				for (int i = 0; i < DataMap.atlist.size(); i++) {

					Atlas at = DataMap.atlist.get(i);

					// 矩形判断
					Rectangle atRect = new Rectangle(at.getXp(), at.getYp(), Data.PLAYER_SIZE, Data.PLAYER_SIZE);

					// 玩家矩形
					Rectangle plRect = new Rectangle(Data.player.getXp(), Data.player.getYp() + 5, 38, 38);
					// 如果碰撞
					if (plRect.intersects(atRect)) {
						// 如果是碰到墙
						if (at instanceof Walls) {

							flag = false;
							// 如果碰到水
						} else if (at instanceof Water) {

							flag = false;
							// 如果碰到铁
						} else if (at instanceof Steels) {

							flag = false;
							// 如果碰到老巢
						} else if (at instanceof Home) {

							flag = false;

						}

					}

				}
				if (flag == true) {

					Data.playerMove = 2;
					Data.player.playerMove();
				}

			}

		} else if (key == KeyEvent.VK_A) {

			if (Data.gamePause == false) {

				flag = true;

				Data.playerDirection = 3;

				for (int i = 0; i < Data.enlist.size(); i++) {

					Enemy en = Data.enlist.get(i);

					// 矩形判断
					Rectangle enRect = new Rectangle(en.getXp(), en.getYp(), Data.PLAYER_SIZE, Data.PLAYER_SIZE);

					// 玩家矩形
					Rectangle plRect = new Rectangle(Data.player.getXp() - 5, Data.player.getYp(), Data.PLAYER_SIZE,
							Data.PLAYER_SIZE);

					// 如果碰撞
					if (enRect.intersects(plRect) == true) {

						flag = false;

					}

				}

				for (int i = 0; i < DataMap.atlist.size(); i++) {

					Atlas at = DataMap.atlist.get(i);

					// 矩形判断
					Rectangle atRect = new Rectangle(at.getXp(), at.getYp(), Data.PLAYER_SIZE, Data.PLAYER_SIZE);

					// 玩家矩形
					Rectangle plRect = new Rectangle(Data.player.getXp() - 5, Data.player.getYp(), 38, 38);
					// 如果碰撞
					if (plRect.intersects(atRect)) {
						// 如果是碰到墙
						if (at instanceof Walls) {

							flag = false;
							// 如果碰到水
						} else if (at instanceof Water) {

							flag = false;
							// 如果碰到铁
						} else if (at instanceof Steels) {

							flag = false;
							// 如果碰到老巢
						} else if (at instanceof Home) {

							flag = false;

						}

					}

				}
				if (flag == true) {

					Data.playerMove = 3;
					Data.player.playerMove();
				}

			}

		} else if (key == KeyEvent.VK_D) {

			if (Data.gamePause == false) {

				flag = true;

				Data.playerDirection = 4;

				for (int i = 0; i < Data.enlist.size(); i++) {

					Enemy en = Data.enlist.get(i);

					// 矩形判断
					Rectangle enRect = new Rectangle(en.getXp(), en.getYp(), Data.PLAYER_SIZE, Data.PLAYER_SIZE);

					// 玩家矩形
					Rectangle plRect = new Rectangle(Data.player.getXp() + 5, Data.player.getYp(), Data.PLAYER_SIZE,
							Data.PLAYER_SIZE);

					// 如果碰撞
					if (enRect.intersects(plRect) == true) {

						flag = false;

					}

				}
				for (int i = 0; i < DataMap.atlist.size(); i++) {

					Atlas at = DataMap.atlist.get(i);

					// 矩形判断
					Rectangle atRect = new Rectangle(at.getXp(), at.getYp(), Data.PLAYER_SIZE, Data.PLAYER_SIZE);

					// 玩家矩形
					Rectangle plRect = new Rectangle(Data.player.getXp() + 5, Data.player.getYp(), 38, 38);
					// 如果碰撞
					if (plRect.intersects(atRect)) {
						// 如果是碰到墙
						if (at instanceof Walls) {

							flag = false;
							// 如果碰到水
						} else if (at instanceof Water) {

							flag = false;
							// 如果碰到铁
						} else if (at instanceof Steels) {

							flag = false;
							// 如果碰到老巢
						} else if (at instanceof Home) {

							flag = false;

						}

					}

				}

				if (flag == true) {

					Data.playerMove = 4;
					Data.player.playerMove();
				}

			}

		}

	}

	@Override
	public void keyReleased(KeyEvent e) {

		// 判断是哪个按键
		int key = e.getKeyCode();

		if (key == KeyEvent.VK_J) {

			// 爆炸音效
			new Thread(new MediaPlayer(Data.PLAY_FIRE)).start();

			if (Data.gamePause == false) {

				Player p = Data.player;

				if (Data.playerDirection == 1) {

					// 子弹的方向 玩家向上的时候
					PlayerBullet pb = new PlayerBullet(p.getXp() + (Data.PLAYER_SIZE - Data.BULLET_SIZE) / 2,
							p.getYp() - Data.HP_DOWN - 5, 1);
					// 加入集合
					Data.pBulletList.add(pb);

				} else if (Data.playerDirection == 2) {
					// 子弹的方向 玩家向下的时候
					PlayerBullet pb = new PlayerBullet(p.getXp() + (Data.PLAYER_SIZE - Data.BULLET_SIZE) / 2,
							p.getYp() + Data.PLAYER_SIZE, 2);
					// 加入集合
					Data.pBulletList.add(pb);

				} else if (Data.playerDirection == 3) {

					// 子弹的方向 玩家向左的时候
					PlayerBullet pb = new PlayerBullet(p.getXp() - Data.PLAYER_SIZE / 2 + 7,
							p.getYp() + Data.PLAYER_SIZE / 2 - 5, 3);
					// 加入集合
					Data.pBulletList.add(pb);

				} else if (Data.playerDirection == 4) {

					// 子弹的方向 玩家向右的时候
					PlayerBullet pb = new PlayerBullet(p.getXp() + Data.PLAYER_SIZE,
							p.getYp() + (Data.PLAYER_SIZE - Data.BULLET_SIZE) / 2, 4);
					// 加入集合
					Data.pBulletList.add(pb);
				}

			}
			// 暂停游戏
		} else if (key == KeyEvent.VK_P) {

			Data.gamePause = true;

			// 加入图片
			f.getGf().getGp().add(pauseLabel);

			pauseLabel.setBounds(125, 67, 350, 466);

			// 继续游戏
		} else if (key == KeyEvent.VK_C) {

			Data.gamePause = false;
			// 移除图片
			f.getGf().getGp().remove(pauseLabel);

		}

	}
}
