package listener;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import thread.BulletBoomThread;
import thread.CreateAtlasThread;
import thread.EnemyAppearBulletThread;
import thread.EnemyAppearThread;
import thread.EnemyBulletMoveThread;
import thread.EnemyCollideAtlasThread;
import thread.EnemyCollidePlayerThread;
import thread.EnemyDirectionThread;
import thread.EnemyHitAtlasThread;
import thread.EnemyHitPlayerThread;
import thread.EnemyMoveThread;
import thread.FunctionPackgeAppearThread;
import thread.MediaPlayer;
import thread.PlayerBulletMoveThread;
import thread.PlayerCollidePackgeThread;
import thread.PlayerHitAtlasThread;
import thread.PlayerHitEnemyThread;
import thread.VictoryThread;
import ui.StartGameFrame;
import util.Data;
import util.DataMap;

public class MenuBarListener implements ActionListener {

	private StartGameFrame f;

	// 暂停图片
	JLabel pauseLabel = new JLabel(new ImageIcon("img/pauseone.png"));

	public MenuBarListener(StartGameFrame f) {

		this.f = f;
	}

	@Override
	public void actionPerformed(ActionEvent e) {

		// 首先获取动作指令
		String action = e.getActionCommand();

		if (action.equals("starts")) {

			Data.gameStart = true;

			// 设置开始游戏不可用
			f.getGf().getStart().setEnabled(false);
			// 设置重新开始可用
			f.getGf().getRestart().setEnabled(true);
			// 设置暂停按钮可以用
			f.getGf().getPauseGame().setEnabled(true);
			// 设置继续按钮可以用
			f.getGf().getConGame().setEnabled(true);

			// 设置自定义按钮可以用
			f.getGf().getDiy().setEnabled(true);

			// 添加玩家移动的监听
			f.getGf().addKeyListener(f.getPlaymovelist());

			// 创建并启动玩家子弹移动的线程
			new PlayerBulletMoveThread(f).start();

			// 创建并启动敌人出现的线程
			new EnemyAppearThread(f).start();

			// 创建并启动敌人移动的线程
			new EnemyMoveThread(f).start();
			// 创建并启动敌人转向的线程
			new EnemyDirectionThread(f).start();
			// 创建启动打击敌人的线程
			new PlayerHitEnemyThread(f).start();
			// 创建启动碰撞敌人的线程
			new EnemyCollidePlayerThread(f).start();

			// 创建并启动画地形的线程
			new CreateAtlasThread(f).start();
			// 创建并启动敌人碰撞地形的线程
			new EnemyCollideAtlasThread(f).start();
			// 创建并启动玩家打地形的线程
			new PlayerHitAtlasThread(f).start();

			// 创建并启动敌人发射子弹的线程
			new EnemyAppearBulletThread(f).start();
			// 创建并启动敌人子弹移动的线程
			new EnemyBulletMoveThread(f).start();
			// 创建并启动敌人打玩家的线程
			new EnemyHitPlayerThread(f).start();
			// 创建并启动敌人打地形的线程
			new EnemyHitAtlasThread(f).start();
			// 创建并启动子弹碰子弹的线程
			new BulletBoomThread(f).start();
			// 启动音乐
			// 音乐
			new Thread(new MediaPlayer(Data.PLAY_ENTERGAME)).start();
			// 创建并启动功能包出现的线程
			new FunctionPackgeAppearThread(f).start();
			// 创建并启动碰撞功能包的线程
			new PlayerCollidePackgeThread(f).start();

			// 创建并启动过关线程
			new VictoryThread(f).start();

		} else if (action.equals("restart")) {

			// 点击按钮设置暂停
			Data.gamePause = true;

			// 弹窗
			int key = JOptionPane.showConfirmDialog(f, "确定要重新开始游戏吗？", "温馨提示", JOptionPane.OK_CANCEL_OPTION);

			if (key == JOptionPane.OK_OPTION) {

				// 设置计分板按钮可以用
				f.getPf().getPp().getNextLevel().setEnabled(true);

				// 移除结束图片
				Data.lastLevel = false;

				// 修改过关休眠时间
				Data.passLevelTime = 500;

				// 清空后台集合
				Data.backEnlist.clear();
				DataMap.backAtlist.clear();

				// 清空敌人集合
				Data.enlist.clear();
				// 清空敌人子弹集合
				Data.enBulletList.clear();
				// 清空玩家子弹集合
				Data.pBulletList.clear();
				// 清空地形集合
				DataMap.atlist.clear();

				// 清空功能包集合
				Data.PackageList.clear();
				// 重置玩家坐标
				Data.player.setXp(200);
				Data.player.setYp(560);
				// 清空未出现敌人数
				Data.yellowEnemyCount = 0;
				Data.pinkEnemyCount = 0;
				Data.greenEnemyCount = 0;
				// 清空统计敌人
				Data.hitGreenEnemyCount = 0;
				Data.hitPinkEnemyCount = 0;
				Data.hitYellowEnemyCount = 0;
				// 清空当前击杀
				Data.nowHit = 0;
				// 清空当前得分
				Data.nowScore = 0;
				// 设置玩家方向
				Data.playerDirection = 1;
				// 设置玩家血量
				Data.player.setHp(3);
				// 设置当前关卡
				Data.nowLevel = 1;
				// 初始化地形
				DataMap.FirstMap();
				// 初始化敌人
				Data.initEnemy();

				// 音乐
				new Thread(new MediaPlayer(Data.PLAY_ENTERGAME)).start();

				// 设置游戏开始
				Data.gameStart = true;
				// 设置没有暂停
				Data.gamePause = false;

				Data.gameOver = false;

			} else {
				// 没暂停
				Data.gamePause = false;
			}

		} else if (action.equals("pauseGame")) {

			int key = JOptionPane.showConfirmDialog(f, "确定要暂停游戏吗？", "温馨提示", JOptionPane.OK_CANCEL_OPTION);

			if (key == JOptionPane.OK_OPTION) {

				Data.gamePause = true;

				// 加入图片
				f.getGf().getGp().add(pauseLabel);

				pauseLabel.setBounds(125, 67, 350, 466);
			}

		} else if (action.equals("conGame")) {

			int key = JOptionPane.showConfirmDialog(f, "确定要继续游戏吗？", "温馨提示", JOptionPane.OK_CANCEL_OPTION);

			if (key == JOptionPane.OK_OPTION) {

				Data.gamePause = false;

				// 移除图片
				f.getGf().getGp().remove(pauseLabel);

			}

		} else if (action.equals("diy")) {

			// 点击按钮设置暂停
			Data.gamePause = true;
			// 自定义窗口可见
			f.getDif().setVisible(true);

		} else if (action.equals("exitt")) {

			// 点击按钮设置暂停
			Data.gamePause = true;
			// 弹窗
			int key = JOptionPane.showConfirmDialog(f, "确定要退出游戏吗？", "退出游戏", JOptionPane.OK_CANCEL_OPTION);

			if (key == JOptionPane.OK_OPTION) {

				// 关闭窗口
				System.exit(0);

			} else {

				// 恢复暂停
				Data.gamePause = false;
			}

		} else if (action.equals("explian")) {

			// 展示说明窗口
			f.getEf().setVisible(true);

		} else if (action.equals("about")) {

			JOptionPane.showMessageDialog(f, "QQ：3201472388  微信公众号：最喜Java");
		}

	}

	public StartGameFrame getF() {
		return f;
	}

	public void setF(StartGameFrame f) {
		this.f = f;
	}

	public JLabel getPauseLabel() {
		return pauseLabel;
	}

	public void setPauseLabel(JLabel pauseLabel) {
		this.pauseLabel = pauseLabel;
	}

}
