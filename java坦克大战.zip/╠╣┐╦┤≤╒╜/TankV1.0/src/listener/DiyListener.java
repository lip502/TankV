package listener;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import thread.MediaPlayer;
import ui.StartGameFrame;
import util.Data;
import util.DataMap;

public class DiyListener implements ActionListener {

	private StartGameFrame f;

	public DiyListener(StartGameFrame f) {

		this.f = f;

	}

	@Override
	public void actionPerformed(ActionEvent e) {

		// 获取动作命令
		String action = e.getActionCommand();

		if (action.equals("selfDefineGame")) {
			// 可以开始设置
			f.getDif().getDip().getLevelBox().setEnabled(true);
			f.getDif().getDip().getEnemySpeedBox().setEnabled(true);
			f.getDif().getDip().getEnemyBulletSpeedBox().setEnabled(true);
			f.getDif().getDip().getEnemyBulletTimeBox().setEnabled(true);
			f.getDif().getDip().getPlayerBulletSpeedBox().setEnabled(true);
			f.getDif().getDip().getEnemyCountText().setEnabled(true);

		} else if (action.equals("normalGame")) {
			// 不可以设置 并且设置回默认值
			f.getDif().getDip().getLevelBox().setSelectedIndex(1);
			f.getDif().getDip().getLevelBox().setEnabled(false);

			f.getDif().getDip().getEnemySpeedBox().setSelectedIndex(2);
			f.getDif().getDip().getEnemySpeedBox().setEnabled(false);

			f.getDif().getDip().getEnemyBulletSpeedBox().setSelectedIndex(2);
			f.getDif().getDip().getEnemyBulletSpeedBox().setEnabled(false);

			f.getDif().getDip().getEnemyBulletTimeBox().setSelectedIndex(2);
			f.getDif().getDip().getEnemyBulletTimeBox().setEnabled(false);

			f.getDif().getDip().getPlayerBulletSpeedBox().setSelectedIndex(2);
			f.getDif().getDip().getPlayerBulletSpeedBox().setEnabled(false);

			f.getDif().getDip().getEnemyCountText().setEnabled(false);

		} else if (action.equals("selfDefineSure")) {

			// 弹窗
			int key = JOptionPane.showConfirmDialog(f, "确定要自定义游戏吗？", "温馨提示", JOptionPane.OK_CANCEL_OPTION);

			if (key == JOptionPane.OK_OPTION) {

				// 确定按钮
				// 音乐
				new Thread(new MediaPlayer(Data.PLAY_ENTERGAME)).start();

				// 设置关卡
				String level = (String) f.getDif().getDip().getLevelBox().getSelectedItem();
				Data.nowLevel = Integer.parseInt(level);

				// 设置敌人速度
				String enemySpeed = (String) f.getDif().getDip().getEnemySpeedBox().getSelectedItem();
				Data.enemyMoveSpeed = Integer.parseInt(enemySpeed);

				// 设置敌人子弹速度
				String enemyShellSpeed = (String) f.getDif().getDip().getEnemyBulletSpeedBox().getSelectedItem();
				Data.enemyBulletSpeed = Integer.parseInt(enemyShellSpeed);

				// 敌人子弹间隔
				String enemyBulletTime = (String) f.getDif().getDip().getEnemyBulletTimeBox().getSelectedItem();
				Data.enemyBulletTime = Integer.parseInt(enemyBulletTime);

				// 玩家子弹速度
				String shellSpeed = (String) f.getDif().getDip().getPlayerBulletSpeedBox().getSelectedItem();
				Data.playerBulletSleep = Integer.parseInt(shellSpeed);

				// 敌人数量
				String enemyCount = f.getDif().getDip().getEnemyCountText().getText();
				
				try {
					Data.EnemyCount = Integer.parseInt(enemyCount);

				} catch (Exception e2) {
					// TODO: handle exception
				}

				// 清空后台集合
				Data.backEnlist.clear();
				DataMap.backAtlist.clear();

				// 清空敌人集合
				Data.enlist.clear();
				// 清空敌人子弹集合
				Data.enBulletList.clear();
				// 清空玩家子弹集合
				Data.pBulletList.clear();
				// 清空地形集合
				DataMap.atlist.clear();
				// 重置玩家坐标
				Data.player.setXp(200);
				Data.player.setYp(560);
				// 清空未出现敌人数
				Data.yellowEnemyCount = 0;
				Data.pinkEnemyCount = 0;
				Data.greenEnemyCount = 0;

				// 清空计分敌人
				Data.hitGreenEnemyCount = 0;
				Data.hitPinkEnemyCount = 0;
				Data.hitYellowEnemyCount = 0;
				// 清空当前击杀
				Data.nowHit = 0;
				// 清空当前得分
				Data.nowScore = 0;
				// 设置玩家方向
				Data.playerDirection = 1;
				// 设置玩家血量
				Data.player.setHp(3);

				// 初始化地形
				if (Data.nowLevel == 1) {

					DataMap.FirstMap();

				} else if (Data.nowLevel == 2) {

					DataMap.SecondMap();

				} else if (Data.nowLevel == 3) {

					DataMap.ThirdMap();
				}
				// 初始化敌人
				Data.initEnemy();
				// 设置游戏开始
				Data.gameStart = true;
				// 设置没有暂停
				Data.gamePause = false;

				Data.gameOver = false;

				// 音乐
				new Thread(new MediaPlayer(Data.PLAY_ENTERGAME)).start();

				// 隐藏窗口
				f.getDif().setVisible(false);

			}

		} else if (action.equals("selfDefineCancel")) {
			// 取消 不显示窗口
			f.getDif().setVisible(false);

			// 取消暂停
			Data.gamePause = false;

		}
	}

}
