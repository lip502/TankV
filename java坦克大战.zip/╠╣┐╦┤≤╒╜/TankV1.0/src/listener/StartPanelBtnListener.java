package listener;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import thread.MediaPlayer;
import ui.StartGameFrame;
import util.Data;
import util.DataMap;

public class StartPanelBtnListener implements ActionListener {

	// 传进顶级容器
	private StartGameFrame f;

	public StartPanelBtnListener(StartGameFrame f) {

		this.f = f;
	}

	@Override
	public void actionPerformed(ActionEvent e) {

		// 首先获取动作指令
		String action = e.getActionCommand();

		if (action.equals("start")) {

			try {

				Data.playerName = JOptionPane.showInputDialog(f, "请输入玩家昵称：", "欢迎来到坦克大战", JOptionPane.OK_CANCEL_OPTION);
				// 判断是否有输入姓名
				if (Data.playerName.trim().equals("")) {

					JOptionPane.showMessageDialog(f, "请将姓名填写完整！");

				} else {

					// 关闭背景音乐
					f.getBackgroundThread().stop();

					// 设置开始游戏窗口不可见
					f.setVisible(false);
					// 设置游戏窗口可见
					f.getGf().setVisible(true);
				}

			} catch (Exception e2) {
				// TODO: handle exception
			}

		} else if (action.equals("exit")) {

			// 弹窗
			int key = JOptionPane.showConfirmDialog(f, "确定要退出游戏吗？", "退出游戏", JOptionPane.OK_CANCEL_OPTION);

			if (key == JOptionPane.OK_OPTION) {

				// 关闭窗口
				System.exit(0);

			}
		} else if (action.equals("nextLevel")) {

			// 清空后台敌人和地形集合
			Data.backEnlist.clear();
			DataMap.backAtlist.clear();

			// 清空敌人集合
			Data.enlist.clear();
			// 清空敌人子弹集合
			Data.enBulletList.clear();
			// 清空玩家子弹集合
			Data.pBulletList.clear();
			// 清空地形集合
			DataMap.atlist.clear();
			// 重置玩家坐标
			Data.player.setXp(200);
			Data.player.setYp(560);
			// 未出现敌人数量
			Data.yellowEnemyCount = 0;
			Data.pinkEnemyCount = 0;
			Data.greenEnemyCount = 0;
			// 清空计分敌人
			Data.hitGreenEnemyCount = 0;
			Data.hitPinkEnemyCount = 0;
			Data.hitYellowEnemyCount = 0;
			// 当前击杀
			Data.nowHit = 0;
			// 当前得分
			Data.nowScore = 0;

			// 玩家向上
			Data.playerDirection = 1;
			// 玩家血量
			Data.player.setHp(3);

			// 关数+1
			Data.nowLevel++;

			// 初始化敌人
			Data.initEnemy();
			// 初始化地形
			if (Data.nowLevel == 2) {

				DataMap.SecondMap();

			} else if (Data.nowLevel == 3) {

				DataMap.ThirdMap();
			}

			// 设置计分板不可见
			f.getPf().setVisible(false);

		} else if (action.equals("exitGame")) {

			// System.out.println("点击了");

			// 弹窗
			int key = JOptionPane.showConfirmDialog(f, "确定要退出游戏吗？", "退出游戏", JOptionPane.OK_CANCEL_OPTION);

			if (key == JOptionPane.OK_OPTION) {

				// 关闭窗口
				System.exit(0);

			}

		} else if (action.equals("rest")) {

			// 点击按钮设置暂停
			Data.gamePause = true;

			Data.aboutJpg = false;

			// 弹窗
			int key = JOptionPane.showConfirmDialog(f, "确定要重新开始游戏吗？", "温馨提示", JOptionPane.OK_CANCEL_OPTION);

			if (key == JOptionPane.OK_OPTION) {

				// 设置计分板按钮可以用
				f.getPf().getPp().getNextLevel().setEnabled(true);

				// 移除结束图片
				Data.lastLevel = false;

				// 修改过关休眠时间
				Data.passLevelTime = 500;

				// 清空后台集合
				Data.backEnlist.clear();
				DataMap.backAtlist.clear();

				// 清空敌人集合
				Data.enlist.clear();
				// 清空敌人子弹集合
				Data.enBulletList.clear();
				// 清空玩家子弹集合
				Data.pBulletList.clear();
				// 清空地形集合
				DataMap.atlist.clear();

				// 清空功能包集合
				Data.PackageList.clear();
				// 重置玩家坐标
				Data.player.setXp(200);
				Data.player.setYp(560);
				// 清空未出现敌人数
				Data.yellowEnemyCount = 0;
				Data.pinkEnemyCount = 0;
				Data.greenEnemyCount = 0;
				// 清空计分敌人
				Data.hitGreenEnemyCount = 0;
				Data.hitPinkEnemyCount = 0;
				Data.hitYellowEnemyCount = 0;
				// 清空当前击杀
				Data.nowHit = 0;
				// 清空当前得分
				Data.nowScore = 0;
				// 设置玩家方向
				Data.playerDirection = 1;
				// 设置玩家血量
				Data.player.setHp(3);
				// 设置当前关卡
				Data.nowLevel = 1;
				// 初始化地形
				DataMap.FirstMap();
				// 初始化敌人
				Data.initEnemy();

				// 音乐
				new Thread(new MediaPlayer(Data.PLAY_ENTERGAME)).start();

				// 设置游戏开始
				Data.gameStart = true;
				// 设置没有暂停
				Data.gamePause = false;

				Data.gameOver = false;

			} else {
				// 没暂停
				Data.gamePause = false;
			}
			// 设置过关面板不可见
			f.getPf().setVisible(false);
		}

	}

}
