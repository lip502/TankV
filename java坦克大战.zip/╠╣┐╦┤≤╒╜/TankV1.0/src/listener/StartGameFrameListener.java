package listener;

import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.JOptionPane;

import ui.StartGameFrame;

public class StartGameFrameListener implements WindowListener {

	// 传进顶级容器
	private StartGameFrame f;

	public StartGameFrameListener(StartGameFrame f) {

		this.f = f;
	}

	@Override
	public void windowOpened(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowClosing(WindowEvent e) {

		// 弹窗
		int key = JOptionPane.showConfirmDialog(f, "确定要退出游戏吗？", "退出游戏", JOptionPane.OK_CANCEL_OPTION);

		if (key == JOptionPane.OK_OPTION) {

			// 关闭窗口
			System.exit(0);

		}
	}

	@Override
	public void windowClosed(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowIconified(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowDeiconified(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowActivated(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowDeactivated(WindowEvent e) {
		// TODO Auto-generated method stub

	}

}
